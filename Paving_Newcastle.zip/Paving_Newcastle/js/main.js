

    // grab the initial top offset of the navigation 
        var stickyNavTop = $('nav').offset().top;

        // our function that decides weather the navigation bar should have "fixed" css position or not.
        var stickyNav = function(){
            var scrollTop = $(window).scrollTop(); // our current vertical position from the top

            // if we've scrolled more than the navigation, change its position to fixed to stick to top,
            // otherwise change it back to relative
            if (scrollTop > stickyNavTop) { 
                jQuery('nav').addClass('sticky');
            } else {
                jQuery('nav').removeClass('sticky'); 
            }
        };

        stickyNav();
        // and run it again every time you scroll
        jQuery(window).scroll(function() {
            stickyNav();
        });

     //slider
    jQuery(".rslides").responsiveSlides();


     jQuery('.regular').slick({
          dots: false,
          autoplay:true,
          infinite: false,
          speed: 300,
          slidesToShow: 3,
          slidesToScroll: 3,
          responsive: [
            {
              breakpoint: 1024,
              settings: {
                slidesToShow: 3,
                slidesToScroll: 3,
                infinite: true,
                dots: true
              }
            },
            {
              breakpoint: 600,
              settings: {
                slidesToShow: 2,
                slidesToScroll: 2
              }
            },
            {
              breakpoint: 480,
              settings: {
                slidesToShow: 1,
                slidesToScroll: 1
              }
            }
            // You can unslick at a given breakpoint now by adding:
            // settings: "unslick"
            // instead of a settings object
          ]
        });

        // sidebar carousel

        jQuery('.autoplay').slick({
          slidesToShow: 1,
          slidesToScroll: 1,
          autoplay: true,
          autoplaySpeed: 2000,
          arrows: false,
            dots: true,
        });


     // testimonials carousel

    jQuery('.one-time').slick({
      dots: true,
      infinite: true,
      autoplay: true,    
      speed: 300,
      slidesToShow: 1,
      adaptiveHeight: true
    });
		
